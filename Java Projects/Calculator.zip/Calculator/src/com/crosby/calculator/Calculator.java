package com.crosby.calculator;

public class Calculator {
	
	public double add(double num1, double num2){
		double result = num1 + num2;
		return result;
	}
	
	public double subtract(double num1, double num2){
		double result1 = num1 - num2;
		return result1;
	}
	
	public double divide(double num1, double num2){
		double result2 = num1 / num2;
		return result2;
	}
	
	public double multiply(double num1, double num2){
		double result3 = num1 * num2;
		return result3;
	}

}
