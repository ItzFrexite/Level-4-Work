package com.crosby.vehiclesim;

public class TestDrive {

	public static void main(String[] args) {

		Engine carengine = new Engine("2L", 4);
		Car myCar = new Car(carengine, false, "Blue", "Black", 10, "Ford", "Focus", 0, 120, 0, 5);
		myCar.accelerate(10);
		myCar.turnOnIgnition();
		myCar.decelerate(5);
		myCar.accelerate(15);
		myCar.accelerate(15);
		myCar.accelerate(20);
		myCar.decelerate(10);
		myCar.accelerate(5);
		myCar.turnOffIgnition();
		myCar.accelerate(10);
		myCar.decelerate(10);
		
		//System.out.println(myCar.currentSpeed);;
		System.out.println(" ");
		
		Engine bikeengine = new Engine("2L", 4);
		Bike myBike = new Bike(bikeengine, false, "Yellow", "Black", 5, "Harley Davidson", "Sportster", 0, 150, 0, false);
		myBike.accelerate(15);
		myBike.turnOnIgnition();
		myBike.decelerate(10);
		myBike.accelerate(25);
		myBike.accelerate(15);
		myBike.accelerate(30);
		myBike.decelerate(5);
		myBike.accelerate(10);
		myBike.turnOffIgnition();
		myBike.accelerate(10);
		myBike.decelerate(15);

	}

}
